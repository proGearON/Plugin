package me.ngt.smp3;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.hover.content.Text;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Chicken;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.WorldLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class NGTSMP3 extends JavaPlugin implements Listener {

    private File logFile;
    private File loaderFile;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
    private String discordLink;
    private int chickenGrowTicks;

    /** Players who currently have chunk borders switched on. */
    private final Set<UUID> borderViewers = new HashSet<>();

    /** Kept-loaded chunks, stored as "world;chunkX;chunkZ". */
    private final Set<String> loaders = new LinkedHashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadSettings();

        logFile = new File(getDataFolder(), "player-logs.txt");
        loaderFile = new File(getDataFolder(), "chunkloaders.yml");
        try {
            if (!getDataFolder().exists()) getDataFolder().mkdirs();
            if (!logFile.exists()) logFile.createNewFile();
        } catch (IOException e) {
            getLogger().severe("Could not create log file: " + e.getMessage());
        }

        Bukkit.getPluginManager().registerEvents(this, this);

        // Fix chickens that are already loaded
        for (World world : Bukkit.getWorlds()) {
            for (Entity e : world.getEntities()) {
                if (e instanceof Chicken) speedUpChicken((Chicken) e);
            }
        }

        // Chunk loaders
        loadLoaders();
        for (World world : Bukkit.getWorlds()) applyLoaders(world);

        // Chunk border particles (every 10 ticks = 0.5s)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (UUID id : new ArrayList<>(borderViewers)) {
                Player p = Bukkit.getPlayer(id);
                if (p != null && p.isOnline()) drawBorder(p);
            }
        }, 20L, 10L);

        getLogger().info("NGT SMP 3 enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("NGT SMP 3 disabled.");
    }

    private void reloadSettings() {
        reloadConfig();
        discordLink = getConfig().getString("discord-link", "https://discord.gg/fhvs6Echr");
        chickenGrowTicks = Math.max(20, getConfig().getInt("chicken-grow-seconds", 60) * 20);
    }

    // ------------------------------------------------------------------
    // Join / Quit logging + Discord message
    // ------------------------------------------------------------------

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        writeLog("JOIN", player.getName());

        long delay = getConfig().getLong("join-message-delay-ticks", 40);
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (player.isOnline()) sendDiscordMessage(player, true);
        }, delay);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        borderViewers.remove(event.getPlayer().getUniqueId());
        writeLog("QUIT", event.getPlayer().getName());
    }

    private synchronized void writeLog(String type, String name) {
        String line = dateFormat.format(new Date()) + "|" + type + "|" + name;
        // write async-safe, small append
        try (BufferedWriter w = Files.newBufferedWriter(logFile.toPath(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write(line);
            w.newLine();
        } catch (IOException e) {
            getLogger().warning("Failed to write log: " + e.getMessage());
        }
    }

    private void sendDiscordMessage(Player player, boolean onJoin) {
        TextComponent prefix = new TextComponent(onJoin
                ? "Welcome to NGT SMP 3! Join our Discord VC: "
                : "Join our Discord VC: ");
        prefix.setColor(ChatColor.GOLD);

        TextComponent link = new TextComponent(discordLink);
        link.setColor(ChatColor.AQUA);
        link.setUnderlined(true);
        link.setBold(true);
        link.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, discordLink));
        link.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                new Text("Click to open Discord")));

        player.spigot().sendMessage(new ComponentBuilder().append(prefix).append(link).create());
    }

    // ------------------------------------------------------------------
    // Commands
    // ------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase();

        if (name.equals("vc")) {
            if (sender instanceof Player) {
                sendDiscordMessage((Player) sender, false);
            } else {
                sender.sendMessage("Discord VC: " + discordLink);
            }
            return true;
        }

        if (name.equals("ngtlogs")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Only players can receive the book.");
                return true;
            }
            Player player = (Player) sender;
            if (!player.isOp() && !player.hasPermission("ngtsmp3.logs")) {
                player.sendMessage(ChatColor.RED + "Only OPs can use this command.");
                return true;
            }
            giveLogBook(player);
            return true;
        }

        if (name.equals("chunkborder")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Only players can view chunk borders.");
                return true;
            }
            toggleBorder((Player) sender);
            return true;
        }

        if (name.equals("chunkload")) {
            if (!sender.isOp() && !sender.hasPermission("ngtsmp3.chunkload")) {
                sender.sendMessage(ChatColor.RED + "Only OPs can use this command.");
                return true;
            }
            handleChunkLoad(sender, label, args);
            return true;
        }
        return false;
    }

    private List<String> readLogs() {
        try {
            List<String> lines = Files.readAllLines(logFile.toPath(), StandardCharsets.UTF_8);
            Collections.reverse(lines); // newest first
            return lines;
        } catch (IOException e) {
            getLogger().warning("Failed to read logs: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    private void giveLogBook(Player player) {
        List<String> lines = readLogs();
        int max = Math.max(1, getConfig().getInt("max-log-entries-in-book", 500));

        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta) book.getItemMeta();
        meta.setTitle("Player Logs");
        meta.setAuthor("Server");

        List<String> pages = new ArrayList<>();
        StringBuilder page = new StringBuilder();
        int linesOnPage = 0;
        int count = 0;

        for (String raw : lines) {
            if (count >= max || pages.size() >= 99) break;
            String[] p = raw.split("\\|", 3);
            if (p.length < 3) continue;

            boolean join = p[1].equals("JOIN");
            String entry = (join ? "§2+ JOIN §0" : "§4- QUIT §0")
                    + p[2] + "\n§8" + p[0] + "§0\n";

            // 5 entries (each 2 lines) per page keeps within the book's page size
            if (linesOnPage >= 5) {
                pages.add(page.toString());
                page = new StringBuilder();
                linesOnPage = 0;
            }
            page.append(entry);
            linesOnPage++;
            count++;
        }
        if (page.length() > 0) pages.add(page.toString());
        if (pages.isEmpty()) pages.add("No logs yet.");

        meta.setPages(pages);
        book.setItemMeta(meta);

        player.getInventory().addItem(book).values()
                .forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
        player.sendMessage(ChatColor.GREEN + "Log book given (" + count + " entries, newest first).");
    }

    // ------------------------------------------------------------------
    // Chunk border viewer (per player, particles only that player sees)
    // ------------------------------------------------------------------

    private void toggleBorder(Player player) {
        UUID id = player.getUniqueId();
        if (borderViewers.remove(id)) {
            player.sendMessage(ChatColor.YELLOW + "Chunk borders: " + ChatColor.RED + "OFF");
        } else {
            borderViewers.add(id);
            Chunk c = player.getLocation().getChunk();
            player.sendMessage(ChatColor.YELLOW + "Chunk borders: " + ChatColor.GREEN + "ON"
                    + ChatColor.GRAY + " (you are in chunk " + c.getX() + ", " + c.getZ()
                    + "). Type /chunkborder again to turn off.");
        }
    }

    private void drawBorder(Player p) {
        Location loc = p.getLocation();
        Chunk chunk = loc.getChunk();
        int minX = chunk.getX() << 4;
        int minZ = chunk.getZ() << 4;
        int maxX = minX + 16;
        int maxZ = minZ + 16;
        double y = loc.getY();

        // Horizontal rings around the player's height
        for (int h = (int) y - 2; h <= (int) y + 6; h += 2) {
            for (int i = 0; i <= 16; i += 2) {
                p.spawnParticle(Particle.END_ROD, minX + i, h, minZ, 1, 0, 0, 0, 0);
                p.spawnParticle(Particle.END_ROD, minX + i, h, maxZ, 1, 0, 0, 0, 0);
                p.spawnParticle(Particle.END_ROD, minX, h, minZ + i, 1, 0, 0, 0, 0);
                p.spawnParticle(Particle.END_ROD, maxX, h, minZ + i, 1, 0, 0, 0, 0);
            }
        }
        // Tall vertical lines on the four corners
        for (double h = y - 8; h <= y + 16; h += 1) {
            p.spawnParticle(Particle.END_ROD, minX, h, minZ, 1, 0, 0, 0, 0);
            p.spawnParticle(Particle.END_ROD, maxX, h, minZ, 1, 0, 0, 0, 0);
            p.spawnParticle(Particle.END_ROD, minX, h, maxZ, 1, 0, 0, 0, 0);
            p.spawnParticle(Particle.END_ROD, maxX, h, maxZ, 1, 0, 0, 0, 0);
        }
    }

    // ------------------------------------------------------------------
    // OP chunk loader (/chunkload add|remove|list)
    // ------------------------------------------------------------------

    private void handleChunkLoad(CommandSender sender, String label, String[] args) {
        if (args.length == 0) {
            sendChunkLoadUsage(sender, label);
            return;
        }
        String sub = args[0].toLowerCase();

        if (sub.equals("list")) {
            if (loaders.isEmpty()) {
                sender.sendMessage(ChatColor.YELLOW + "No chunks are being kept loaded.");
                return;
            }
            sender.sendMessage(ChatColor.GOLD + "Kept-loaded chunks (" + loaders.size() + "):");
            for (String key : loaders) {
                String[] p = key.split(";");
                int cx = Integer.parseInt(p[1]);
                int cz = Integer.parseInt(p[2]);
                sender.sendMessage(ChatColor.GRAY + "- " + ChatColor.WHITE + p[0]
                        + ChatColor.GRAY + " chunk " + cx + ", " + cz
                        + " (blocks X " + (cx << 4) + " to " + ((cx << 4) + 15)
                        + ", Z " + (cz << 4) + " to " + ((cz << 4) + 15) + ")");
            }
            return;
        }

        if (!sub.equals("add") && !sub.equals("remove")) {
            sendChunkLoadUsage(sender, label);
            return;
        }

        World world;
        int blockX;
        int blockZ;

        if (args.length == 1) {
            // No coordinates: use the chunk the player is standing in
            if (!(sender instanceof Player)) {
                sender.sendMessage(ChatColor.RED + "From console give coordinates: /" + label
                        + " " + sub + " <blockX> <blockZ> [world]");
                return;
            }
            Location l = ((Player) sender).getLocation();
            world = l.getWorld();
            blockX = l.getBlockX();
            blockZ = l.getBlockZ();
        } else if (args.length >= 3) {
            try {
                blockX = Integer.parseInt(args[1]);
                blockZ = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "X and Z must be whole block coordinates.");
                return;
            }
            if (args.length >= 4) {
                world = Bukkit.getWorld(args[3]);
                if (world == null) {
                    sender.sendMessage(ChatColor.RED + "World '" + args[3] + "' not found.");
                    return;
                }
            } else if (sender instanceof Player) {
                world = ((Player) sender).getWorld();
            } else {
                world = Bukkit.getWorlds().get(0); // main world for console
            }
        } else {
            sendChunkLoadUsage(sender, label);
            return;
        }

        int cx = Math.floorDiv(blockX, 16);
        int cz = Math.floorDiv(blockZ, 16);
        String key = world.getName() + ";" + cx + ";" + cz;
        String area = "chunk " + cx + ", " + cz + " in " + world.getName()
                + " (blocks X " + (cx << 4) + " to " + ((cx << 4) + 15)
                + ", Z " + (cz << 4) + " to " + ((cz << 4) + 15) + ")";

        if (sub.equals("add")) {
            if (!loaders.add(key)) {
                sender.sendMessage(ChatColor.YELLOW + "Already kept loaded: " + area);
                return;
            }
            world.setChunkForceLoaded(cx, cz, true);
            saveLoaders();
            sender.sendMessage(ChatColor.GREEN + "Now keeping " + area + " loaded.");
        } else {
            if (!loaders.remove(key)) {
                sender.sendMessage(ChatColor.YELLOW + "That chunk is not in the loader list: " + area);
                return;
            }
            world.setChunkForceLoaded(cx, cz, false);
            saveLoaders();
            sender.sendMessage(ChatColor.GREEN + "Stopped keeping " + area + " loaded.");
        }
    }

    private void sendChunkLoadUsage(CommandSender sender, String label) {
        sender.sendMessage(ChatColor.GOLD + "Chunk loader usage:");
        sender.sendMessage(ChatColor.YELLOW + "/" + label + " add" + ChatColor.GRAY
                + " - keep the chunk you stand in loaded (player)");
        sender.sendMessage(ChatColor.YELLOW + "/" + label + " add <blockX> <blockZ> [world]" + ChatColor.GRAY
                + " - works from console");
        sender.sendMessage(ChatColor.YELLOW + "/" + label + " remove [<blockX> <blockZ> [world]]");
        sender.sendMessage(ChatColor.YELLOW + "/" + label + " list");
    }

    private void applyLoaders(World world) {
        for (String key : loaders) {
            String[] p = key.split(";");
            if (!p[0].equals(world.getName())) continue;
            world.setChunkForceLoaded(Integer.parseInt(p[1]), Integer.parseInt(p[2]), true);
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        applyLoaders(event.getWorld());
    }

    private void loadLoaders() {
        loaders.clear();
        if (!loaderFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(loaderFile);
        for (String key : yml.getStringList("loaders")) {
            String[] p = key.split(";");
            if (p.length != 3) continue;
            try {
                Integer.parseInt(p[1]);
                Integer.parseInt(p[2]);
                loaders.add(key);
            } catch (NumberFormatException ignored) {
            }
        }
    }

    private void saveLoaders() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("loaders", new ArrayList<>(loaders));
        try {
            yml.save(loaderFile);
        } catch (IOException e) {
            getLogger().warning("Failed to save chunk loaders: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------
    // Baby chicken fast growth
    // ------------------------------------------------------------------

    @EventHandler
    public void onSpawn(CreatureSpawnEvent event) {
        if (!(event.getEntity() instanceof Chicken)) return;
        Chicken chicken = (Chicken) event.getEntity();
        // run next tick so the final age is already applied (e.g. egg hatch, breeding)
        Bukkit.getScheduler().runTask(this, () -> speedUpChicken(chicken));
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        for (Entity e : event.getChunk().getEntities()) {
            if (e instanceof Chicken) speedUpChicken((Chicken) e);
        }
    }

    /** Baby age counts up from a negative number to 0 by 1 per tick. Clamp it to -N ticks. */
    private void speedUpChicken(Chicken chicken) {
        if (chicken == null || chicken.isDead() || chicken.isAdult()) return;
        if (chicken.getAge() < -chickenGrowTicks) {
            chicken.setAge(-chickenGrowTicks);
        }
    }
}
